"""
VidForge Pro — Complete Server
Features:
- Pixabay + Pexels free stock footage
- Topic-specific footage search
- Landscape / Portrait / Square orientation
- 720p / 1080p / 1440p / 4K quality
- Edge-TTS + gTTS + pyttsx3 fallback
- Subtitle fallback (with/without)
- Windows path fix
"""

import os, json, asyncio, requests as req, subprocess, time, re, uuid
import logging, shutil, threading
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse

logging.basicConfig(level=logging.INFO,
    format="%(asctime)s %(message)s", datefmt="%H:%M:%S")
log = logging.getLogger()

BASE = Path(__file__).parent
OUT  = BASE / "output"; OUT.mkdir(exist_ok=True)
TEMP = BASE / "temp";   TEMP.mkdir(exist_ok=True)
JOBS = {}

# ── Resolution & Orientation ──────────────────────────────────────────────────
RESOLUTIONS = {
    "720p":  {"landscape": (1280, 720),  "portrait": (720, 1280),  "square": (720, 720)},
    "1080p": {"landscape": (1920, 1080), "portrait": (1080, 1920), "square": (1080, 1080)},
    "1440p": {"landscape": (2560, 1440), "portrait": (1440, 2560), "square": (1440, 1440)},
    "4k":    {"landscape": (3840, 2160), "portrait": (2160, 3840), "square": (2160, 2160)},
}

CRF_MAP = {"720p": "24", "1080p": "22", "1440p": "20", "4k": "18"}
PRESET_MAP = {"720p": "fast", "1080p": "fast", "1440p": "medium", "4k": "slow"}

def get_dims(quality="1080p", orientation="landscape"):
    q = quality.lower() if quality.lower() in RESOLUTIONS else "1080p"
    o = orientation.lower() if orientation.lower() in ["landscape","portrait","square"] else "landscape"
    return RESOLUTIONS[q][o]

def get_scale_filter(quality="1080p", orientation="landscape"):
    w, h = get_dims(quality, orientation)
    return f"scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},format=yuv420p"

# ── TTS ───────────────────────────────────────────────────────────────────────
def detect_tts():
    engines = []
    try: import edge_tts; engines.append("edge")
    except: pass
    try: from gtts import gTTS; engines.append("gtts")
    except: pass
    try: import pyttsx3; engines.append("pyttsx3")
    except: pass
    return engines

TTS_ENGINES = detect_tts()

async def _edge(text, path, voice, rate, pitch):
    import edge_tts
    await asyncio.wait_for(
        edge_tts.Communicate(text[:300], voice, rate=rate, pitch=pitch).save(path),
        timeout=15)

def make_voice(text, path, voice="en-US-AriaNeural", rate="+0%", pitch="+0Hz"):
    if "edge" in TTS_ENGINES:
        for attempt in range(2):
            try:
                asyncio.run(_edge(text, path, voice, rate, pitch))
                if os.path.exists(path) and os.path.getsize(path) > 300:
                    log.info("TTS: edge-tts ✅"); return True
            except Exception as e:
                log.warning(f"TTS edge {attempt+1}: {e}")
            time.sleep(1)
    if "gtts" in TTS_ENGINES:
        try:
            from gtts import gTTS
            lang_map = {"ur":"ur","hi":"hi","ar":"ar","fr":"fr","de":"de",
                       "es":"es","zh":"zh-CN","ja":"ja","ko":"ko","tr":"tr","ru":"ru"}
            lang = lang_map.get(voice[:2].lower(), "en")
            gTTS(text[:400], lang=lang).save(path)
            if os.path.exists(path) and os.path.getsize(path) > 300:
                log.info("TTS: gTTS ✅"); return True
        except Exception as e:
            log.warning(f"TTS gTTS: {e}")
    if "pyttsx3" in TTS_ENGINES:
        try:
            import pyttsx3
            engine = pyttsx3.init()
            engine.setProperty('rate', 170)
            wav = path.replace(".mp3", ".wav")
            engine.save_to_file(text[:400], wav)
            engine.runAndWait(); engine.stop()
            if os.path.exists(wav):
                subprocess.run(["ffmpeg","-i",wav,"-c:a","libmp3lame",
                    "-q:a","4","-y",path], capture_output=True, timeout=15)
                try: os.remove(wav)
                except: pass
            if os.path.exists(path) and os.path.getsize(path) > 300:
                log.info("TTS: pyttsx3 ✅"); return True
        except Exception as e:
            log.warning(f"TTS pyttsx3: {e}")
    # Silent fallback
    log.warning("TTS: all failed, using silent audio")
    subprocess.run(["ffmpeg","-f","lavfi","-i","anullsrc=r=44100:cl=stereo",
        "-t","10","-c:a","libmp3lame","-q:a","9","-y",path],
        capture_output=True, timeout=15)
    return os.path.exists(path)

def get_duration(path):
    try:
        r = subprocess.run(["ffprobe","-v","error","-show_entries","format=duration",
            "-of","default=noprint_wrappers=1:nokey=1",path],
            capture_output=True, text=True, timeout=8)
        return max(1.0, float(r.stdout.strip()))
    except: return 10.0

# ── Script ────────────────────────────────────────────────────────────────────
LINES = [
    "Did you know that {t} is one of the most fascinating subjects in the world? Today we explore everything you need to know.",
    "The story of {t} is far stranger than most people realize. Scientists have spent decades uncovering its deepest secrets.",
    "What makes {t} truly remarkable is how it connects to almost every aspect of our lives, whether we notice it or not.",
    "The most surprising facts about {t} are the ones that most textbooks never tell you. Let us uncover the truth right now.",
    "Experts around the world agree that {t} will play a massive role in shaping our future. Here is exactly why it matters.",
    "Here are facts about {t} that will completely change how you see the world and everything around you.",
    "The history of {t} goes back much further than you might think, full of incredible twists and discoveries.",
    "Understanding {t} gives you a completely new perspective on how the world actually works at its deepest level.",
    "Scientists continue to discover new things about {t} every year that challenge everything we thought we knew.",
    "Now you understand {t} at a deeper level than most people ever will. Share this knowledge with those around you.",
]

def make_script(topic, duration):
    n = max(3, min(duration // 10, 10))
    words = topic.lower().split()
    base = topic if len(topic) <= 25 else " ".join(words[:3])

    # Topic-specific keywords for footage search
    visual_kws = []
    for i in range(n):
        if i % 5 == 0: visual_kws.append(base)
        elif i % 5 == 1: visual_kws.append(f"{words[0]} {words[1] if len(words)>1 else ''}")
        elif i % 5 == 2: visual_kws.append(f"{base} 4k")
        elif i % 5 == 3: visual_kws.append(words[0] if words else base)
        else: visual_kws.append(base)

    scenes = [{"scene_number": i+1,
               "narration": LINES[i % len(LINES)].replace("{t}", topic),
               "visual_keyword": visual_kws[i].strip()} for i in range(n)]

    # Try Ollama
    try:
        r = req.post("http://localhost:11434/api/generate", json={
            "model": "llama3",
            "prompt": (f'YouTube script about "{topic}". JSON only: title, description, tags(array), '
                      f'scenes(array {n} items: scene_number, narration, visual_keyword). '
                      f'visual_keyword = 2-3 words DIRECTLY about "{topic}" for stock footage search. '
                      f'~{duration*2} words total. No host intro. JSON only.'),
            "stream": False, "options": {"temperature": 0.7, "num_predict": 1200}
        }, timeout=8)
        if r.status_code == 200:
            raw = re.sub(r"```json|```", "", r.json().get("response","")).strip()
            m = re.search(r"\{.*\}", raw, re.DOTALL)
            if m:
                s = json.loads(m.group())
                if isinstance(s.get("scenes"), list) and len(s["scenes"]) >= 2:
                    log.info("Script: Ollama ✅"); return s
    except: pass

    log.info("Script: Smart Templates")
    return {
        "title": f"Amazing Facts About {topic} You Never Knew",
        "description": f"Explore {topic} in depth — the most surprising facts, history, and real-world impact!",
        "tags": [topic, f"{topic} facts", "educational", "documentary", "facts", "learning"],
        "scenes": scenes
    }

# ── Footage ───────────────────────────────────────────────────────────────────
PALETTES = {
    "space":   ("050510","0d1b4b","1a237e"),
    "tech":    ("020c14","0d2137","0a3d62"),
    "nature":  ("071a0e","0d3320","145a32"),
    "science": ("0a0a2e","1a237e","311b92"),
    "history": ("1a0a00","2d1b00","4a2800"),
    "default": ("080812","0f0f2a","16163a"),
}
_cache = {}

def make_background(keyword, out_path, duration, quality="1080p", orientation="landscape"):
    kw = keyword.lower()
    theme = next((k for k in PALETTES if k in kw), "default")
    c1, c2, c3 = PALETTES[theme]
    w, h = get_dims(quality, orientation)
    try:
        subprocess.run([
            "ffmpeg", "-f", "lavfi",
            "-i", f"color=c=#{c1}:size={w}x{h}:rate=30",
            "-t", str(duration + 1),
            "-vf", (f"geq=r='clip(sin(2*PI*X/{w//2}+2*PI*N/150)*50+0x{c2[:2]},0,255)':"
                    f"g='clip(cos(2*PI*Y/{h//2}+2*PI*N/200)*35+0x{c2[2:4]},0,255)':"
                    f"b='clip(sin(2*PI*(X+Y)/{(w+h)//2}+2*PI*N/100)*60+0x{c3[4:6]},0,255)'"),
            "-c:v", "libx264", "-preset", "ultrafast", "-crf", "26", "-y", out_path
        ], capture_output=True, timeout=120)
        if os.path.exists(out_path) and os.path.getsize(out_path) > 100:
            return True
    except Exception as e:
        log.warning(f"Animated bg failed: {e}")
    # Solid fallback
    subprocess.run([
        "ffmpeg", "-f", "lavfi",
        "-i", f"color=c=#{c1}:size={w}x{h}:rate=30",
        "-t", str(duration+1), "-c:v", "libx264",
        "-preset", "ultrafast", "-y", out_path
    ], capture_output=True, timeout=60)
    return os.path.exists(out_path)

def get_footage(keyword, out_path, duration, pexels_key="", pixabay_key="",
                quality="1080p", orientation="landscape"):
    if not pexels_key and not pixabay_key:
        return make_background(keyword, out_path, duration, quality, orientation)

    # Cache
    cache_key = f"{keyword}_{quality}_{orientation}"
    if cache_key in _cache and os.path.exists(_cache[cache_key]):
        w, h = get_dims(quality, orientation)
        subprocess.run(["ffmpeg","-i",_cache[cache_key],"-t",str(duration+1),
            "-vf",f"scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h}",
            "-c:v","libx264","-preset","ultrafast","-an","-y",out_path],
            capture_output=True, timeout=60)
        if os.path.exists(out_path): return True

    # Smart query list
    words = keyword.lower().split()
    queries = [
        keyword,
        " ".join(words[:2]) if len(words) >= 2 else keyword,
        words[0] if words else keyword,
        keyword + " HD",
        "space universe",
        "nature landscape",
    ]

    def save_footage(url):
        raw = str(TEMP / f"raw_{int(time.time())}.mp4")
        try:
            dl = req.get(url, stream=True, timeout=35)
            if dl.status_code == 200:
                with open(raw, "wb") as f:
                    for chunk in dl.iter_content(8192): f.write(chunk)
                w, h = get_dims(quality, orientation)
                subprocess.run(["ffmpeg","-i",raw,"-t",str(duration+1),
                    "-vf",f"scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h}",
                    "-c:v","libx264","-preset","ultrafast","-an","-y",out_path],
                    capture_output=True, timeout=120)
                try: os.remove(raw)
                except: pass
                if os.path.exists(out_path) and os.path.getsize(out_path) > 100:
                    _cache[cache_key] = out_path
                    return True
        except Exception as e:
            log.warning(f"Download: {e}")
            try:
                if os.path.exists(raw): os.remove(raw)
            except: pass
        return False

    # ── Pixabay ───────────────────────────────────────────────────────────────
    if pixabay_key:
        for query in queries:
            try:
                r = req.get("https://pixabay.com/api/videos/",
                    params={"key": pixabay_key, "q": query,
                            "video_type": "film", "per_page": 5,
                            "safesearch": "true"},
                    timeout=10)
                if r.status_code == 200:
                    for hit in r.json().get("hits", []):
                        for size in ["large", "medium", "small", "tiny"]:
                            url = hit.get("videos", {}).get(size, {}).get("url")
                            if url:
                                if save_footage(url):
                                    log.info(f"Pixabay ✅ '{query}'")
                                    return True
                                break
                elif r.status_code == 400:
                    log.warning("Pixabay: Invalid API key")
                    break
            except Exception as e:
                log.warning(f"Pixabay '{query}': {e}")

    # ── Pexels ────────────────────────────────────────────────────────────────
    if pexels_key:
        orient_map = {"landscape": "landscape", "portrait": "portrait", "square": "square"}
        for query in queries[:4]:
            try:
                r = req.get("https://api.pexels.com/videos/search",
                    headers={"Authorization": pexels_key},
                    params={"query": query, "per_page": 5,
                            "orientation": orient_map.get(orientation, "landscape")},
                    timeout=10)
                if r.status_code == 200:
                    for v in r.json().get("videos", []):
                        files = [f for f in v.get("video_files",[]) if f.get("width",0) >= 1280]
                        if not files: continue
                        best = sorted(files, key=lambda x: x.get("width",0))[-1]
                        if save_footage(best["link"]):
                            log.info(f"Pexels ✅ '{query}'")
                            return True
            except Exception as e:
                log.warning(f"Pexels '{query}': {e}")

    log.warning(f"No footage for '{keyword}' — background used")
    return make_background(keyword, out_path, duration, quality, orientation)

# ── Subtitles ─────────────────────────────────────────────────────────────────
def make_srt(scenes, durations, srt_path):
    def ts(t):
        h,m,s,ms = int(t//3600),int((t%3600)//60),int(t%60),int((t%1)*1000)
        return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
    lines, idx, cur = [], 1, 0.0
    for scene, dur in zip(scenes, durations):
        words = scene["narration"].split()
        chunks = [" ".join(words[i:i+8]) for i in range(0, len(words), 8)]
        if not chunks: cur += dur; continue
        cd = dur / len(chunks)
        for chunk in chunks:
            lines.append(f"{idx}\n{ts(cur)} --> {ts(cur+cd)}\n{chunk}\n")
            idx += 1; cur += cd
    with open(srt_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

# ── Assembly ──────────────────────────────────────────────────────────────────
def assemble_video(video_clips, audio_files, durations, srt_path,
                   out_path, burn_subs=True, quality="1080p", orientation="landscape"):
    log.info(f"Assembly: {quality} {orientation} | {len(video_clips)} scenes")
    w, h = get_dims(quality, orientation)
    crf = CRF_MAP.get(quality, "22")
    preset = PRESET_MAP.get(quality, "fast")
    scale_vf = f"scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},format=yuv420p"

    scene_files = []
    for i, (v, a, d) in enumerate(zip(video_clips, audio_files, durations)):
        if not os.path.exists(v): continue
        if not a or not os.path.exists(a):
            a = str(TEMP / f"sil{i}.mp3")
            subprocess.run(["ffmpeg","-f","lavfi","-i","anullsrc=r=44100:cl=stereo",
                "-t",str(d),"-c:a","libmp3lame","-q:a","9","-y",a],
                capture_output=True, timeout=15)
        sc = str(TEMP / f"sc{i:03d}.mp4")
        subprocess.run([
            "ffmpeg", "-i", v, "-i", a,
            "-vf", scale_vf,
            "-c:v", "libx264", "-preset", "ultrafast", "-crf", "24",
            "-c:a", "aac", "-b:a", "128k",
            "-t", str(d + 0.5), "-shortest", "-y", sc
        ], capture_output=True, timeout=180)
        if os.path.exists(sc) and os.path.getsize(sc) > 500:
            scene_files.append(sc)

    if not scene_files:
        log.error("Assembly: no scenes!")
        return False

    concat_file = str(TEMP / "concat.txt")
    with open(concat_file, "w") as f:
        for s in scene_files: f.write(f"file '{s}'\n")

    merged = str(TEMP / "merged.mp4")
    subprocess.run(["ffmpeg","-f","concat","-safe","0",
        "-i",concat_file,"-c","copy","-y",merged],
        capture_output=True, timeout=180)

    if not os.path.exists(merged):
        log.error("Assembly: merge failed!")
        return False

    def render(use_subs):
        vf = f"scale={w}:{h}"
        if use_subs and os.path.exists(srt_path):
            try:
                safe_srt = str(TEMP / "sub.srt")
                shutil.copy2(srt_path, safe_srt)
                esc = safe_srt.replace("\\", "/")
                esc = re.sub(r"^([A-Za-z]):/", r"\1\\:/", esc)
                # Scale font size based on resolution
                font_size = 14 if h <= 720 else 18 if h <= 1080 else 24
                vf += (f",subtitles='{esc}':force_style='"
                       f"FontName=Arial,FontSize={font_size},"
                       "PrimaryColour=&H00FFFFFF,"
                       "OutlineColour=&H00000000,"
                       "BackColour=&H80000000,"
                       "Bold=1,Outline=2,Shadow=1,"
                       "Alignment=2,MarginV=40'")
                log.info(f"Assembly: rendering WITH subtitles ({quality} {orientation})")
            except Exception as e:
                log.warning(f"Subtitle path error: {e}")
                vf = f"scale={w}:{h}"
        r = subprocess.run([
            "ffmpeg", "-i", merged, "-vf", vf,
            "-c:v", "libx264", "-preset", preset, "-crf", crf,
            "-c:a", "aac", "-b:a", "192k",
            "-movflags", "+faststart", "-y", out_path
        ], capture_output=True, text=True, timeout=600)
        return os.path.exists(out_path) and os.path.getsize(out_path) > 5000, r.stderr

    if burn_subs:
        ok, err = render(True)
        if not ok:
            log.warning("Subtitles failed, retrying without...")
            try: os.remove(out_path)
            except: pass
            ok, err = render(False)
    else:
        ok, err = render(False)

    for f in scene_files + [merged, concat_file]:
        try: os.remove(f)
        except: pass

    if ok:
        size = os.path.getsize(out_path) // 1024 // 1024
        log.info(f"VIDEO DONE ✅ {size}MB | {quality} {orientation} → {out_path}")
    else:
        log.error(f"VIDEO FAILED ❌ {err[-400:]}")
    return ok

# ── Pipeline ──────────────────────────────────────────────────────────────────
def run_pipeline(job_id, topic, duration, voice, pexels_key, pixabay_key,
                 rate, pitch, burn_subs, quality, orientation):
    def upd(p, m):
        JOBS[job_id].update({"progress": p, "message": m})
        log.info(f"[{p:3d}%] {m}")

    upd(5, "Generating script...")
    script = make_script(topic, duration)
    scenes = script["scenes"]
    upd(15, f"Script ready — {len(scenes)} scenes | {quality} {orientation} | TTS: {TTS_ENGINES[0] if TTS_ENGINES else 'silent'}")

    prefix = str(TEMP / f"job_{job_id[:8]}")
    audio_files, video_clips, audio_durations = [], [], []

    for i, scene in enumerate(scenes):
        pct = 15 + int((i / len(scenes)) * 55)
        upd(pct, f"Scene {i+1}/{len(scenes)}: voice...")
        ap = f"{prefix}_a{i:03d}.mp3"
        make_voice(scene["narration"], ap, voice, rate, pitch)
        dur = get_duration(ap) if os.path.exists(ap) else 8.0
        audio_durations.append(dur)
        audio_files.append(ap)

        upd(pct + 2, f"Scene {i+1}/{len(scenes)}: footage ({scene['visual_keyword']})...")
        vp = f"{prefix}_v{i:03d}.mp4"
        get_footage(scene["visual_keyword"], vp, dur + 1.5,
                   pexels_key, pixabay_key, quality, orientation)
        video_clips.append(vp)

    upd(73, "Creating subtitles...")
    srt = f"{prefix}_subs.srt"
    make_srt(scenes, audio_durations, srt)

    upd(78, f"Assembling {quality} {orientation} video...")
    out = str(OUT / f"{job_id}.mp4")
    ok = assemble_video(video_clips, audio_files, audio_durations,
                        srt, out, burn_subs, quality, orientation)

    for f in audio_files + video_clips + [srt]:
        try:
            if f and os.path.exists(f): os.remove(f)
        except: pass

    if ok:
        size_mb = os.path.getsize(out) // 1024 // 1024
        JOBS[job_id].update({
            "status": "completed", "progress": 100, "message": "Video ready!",
            "result": {
                **script,
                "video_file": f"{job_id}.mp4",
                "scenes": len(scenes),
                "voice": voice,
                "quality": quality,
                "orientation": orientation,
                "size_mb": size_mb
            }
        })
    else:
        JOBS[job_id].update({
            "status": "failed",
            "message": "Assembly failed — check CMD window"
        })

# ── HTTP Server ───────────────────────────────────────────────────────────────
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def send_json(self, data, code=200):
        body = json.dumps(data).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.cors()
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(200); self.cors(); self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path

        if path == "/health":
            ollama = "offline"
            try:
                r = req.get("http://localhost:11434/api/tags", timeout=1)
                if r.status_code == 200:
                    models = [m["name"] for m in r.json().get("models", [])]
                    ollama = f"online · {', '.join(models)}" if models else "online"
            except: pass
            self.send_json({
                "status": "running", "version": "Pro",
                "tts_engines": TTS_ENGINES, "ollama": ollama,
                "disk_free_gb": round(shutil.disk_usage(str(OUT)).free / 1024**3, 1),
                "jobs": len(JOBS)
            })

        elif path.startswith("/api/status/"):
            jid = path.split("/")[-1]
            self.send_json(JOBS.get(jid, {"error": "not found"}),
                          200 if jid in JOBS else 404)

        elif path.startswith("/api/download/"):
            jid = path.split("/")[-1]
            vp = OUT / f"{jid}.mp4"
            if not vp.exists(): self.send_json({"error": "not found"}, 404); return
            r = JOBS.get(jid, {}).get("result", {})
            title = r.get("title", "video")
            quality = r.get("quality", "1080p")
            orientation = r.get("orientation", "landscape")
            safe = re.sub(r"[^\w\s-]", "_", title)[:40]
            fname = f"{safe}_{quality}_{orientation}.mp4"
            body = vp.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "video/mp4")
            self.send_header("Content-Disposition", f'attachment; filename="{fname}"')
            self.send_header("Content-Length", str(len(body)))
            self.cors(); self.end_headers()
            self.wfile.write(body)

        elif path.startswith("/videos/"):
            vp = OUT / path.split("/")[-1]
            if not vp.exists(): self.send_json({"error": "not found"}, 404); return
            body = vp.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "video/mp4")
            self.send_header("Content-Length", str(len(body)))
            self.cors(); self.end_headers()
            self.wfile.write(body)

        else:
            self.send_json({"error": "not found"}, 404)

    def do_POST(self):
        if urlparse(self.path).path == "/api/generate":
            n = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(n) or b"{}")
            topic = body.get("topic", "").strip()
            if not topic or len(topic) < 3:
                self.send_json({"error": "Topic too short"}, 400); return
            jid = uuid.uuid4().hex[:14]
            JOBS[jid] = {
                "job_id": jid, "status": "processing",
                "progress": 0, "message": "Starting...", "result": None
            }
            threading.Thread(target=run_pipeline, kwargs={
                "job_id":      jid,
                "topic":       topic,
                "duration":    max(30, min(int(body.get("duration", 60)), 300)),
                "voice":       body.get("voice", "en-US-AriaNeural"),
                "pexels_key":  body.get("pexels_key", ""),
                "pixabay_key": body.get("pixabay_key", ""),
                "rate":        body.get("tts_rate", "+0%"),
                "pitch":       body.get("tts_pitch", "+0Hz"),
                "burn_subs":   body.get("burn_subtitles", True),
                "quality":     body.get("quality", "1080p"),
                "orientation": body.get("orientation", "landscape"),
            }, daemon=True).start()
            self.send_json(JOBS[jid])
        else:
            self.send_json({"error": "not found"}, 404)

# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("\n" + "="*52)
    print("  VidForge Pro — AI Faceless Video Generator")
    print("="*52)
    try:
        subprocess.run(["ffmpeg","-version"], capture_output=True, check=True, timeout=5)
        print("  ✅ FFmpeg OK")
    except FileNotFoundError:
        print("  ❌ FFmpeg missing!")
        print("  Fix: PowerShell Admin → winget install ffmpeg")
        input("  Press Enter..."); exit()
    if not TTS_ENGINES:
        print("  Installing TTS...")
        subprocess.run(["pip","install","edge-tts","gTTS","pyttsx3","-q"])
        TTS_ENGINES.extend(detect_tts())
    print(f"  ✅ TTS: {', '.join(TTS_ENGINES) if TTS_ENGINES else 'none'}")
    try:
        r = req.get("http://localhost:11434/api/tags", timeout=1)
        models = [m["name"] for m in r.json().get("models", [])]
        print(f"  ✅ Ollama: {', '.join(models)}")
    except:
        print("  ℹ️  Ollama: offline (smart templates will be used)")
    print(f"\n  🌐 Open: VidForge.html in browser")
    print(f"  📁 Output: {OUT}")
    print(f"  ✅ KEEP THIS WINDOW OPEN!")
    print("="*52 + "\n")
    try:
        HTTPServer(("0.0.0.0", 8000), Handler).serve_forever()
    except KeyboardInterrupt:
        print("\n  Server stopped.")
