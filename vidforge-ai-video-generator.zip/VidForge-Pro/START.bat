@echo off
title VidForge Pro
color 0A
cd /d "%~dp0"
echo.
echo  ============================================
echo   VidForge Pro — AI Faceless Video Generator
echo   720p / 1080p / 1440p / 4K
echo   Landscape / Portrait / Square
echo  ============================================
echo.
python --version >nul 2>&1
if %errorlevel% NEQ 0 (
    echo  ERROR: Python not installed!
    echo  Download: https://python.org/downloads
    echo  Tick "Add Python to PATH" during install!
    pause & exit /b 1
)
ffmpeg -version >nul 2>&1
if %errorlevel% NEQ 0 (
    echo  ERROR: FFmpeg not found!
    echo  Run in PowerShell Admin: winget install ffmpeg
    pause & exit /b 1
)
echo  Installing packages...
pip install edge-tts gTTS pyttsx3 requests -q 2>nul
echo  OK.
echo.
timeout /t 2 /nobreak >nul
start "" "%~dp0VidForge.html"
echo  ============================================
echo   Server: http://localhost:8000
echo   KEEP THIS WINDOW OPEN!
echo  ============================================
echo.
python server.py
pause
