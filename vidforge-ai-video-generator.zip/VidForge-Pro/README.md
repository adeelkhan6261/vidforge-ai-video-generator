# 🎬 VidForge Pro — AI Faceless Video Generator

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.10+-3776AB?style=for-the-badge&logo=python&logoColor=white"/>
  <img src="https://img.shields.io/badge/FFmpeg-Latest-007808?style=for-the-badge&logo=ffmpeg&logoColor=white"/>
  <img src="https://img.shields.io/badge/License-MIT-green?style=for-the-badge"/>
  <img src="https://img.shields.io/badge/Cost-$0%2Fmonth-brightgreen?style=for-the-badge"/>
  <img src="https://img.shields.io/badge/Platform-Windows-0078D6?style=for-the-badge&logo=windows"/>
</p>

<p align="center">
  <b>Turn any topic into a complete, YouTube-ready faceless video — 100% free, runs entirely on your local machine.</b>
</p>

---

## 🌟 What Is VidForge Pro?

VidForge Pro is a **fully local, open-source AI pipeline** that automatically generates faceless YouTube videos from a single text prompt. You type a topic — it writes the script, generates a professional voiceover, downloads real stock footage from Pixabay/Pexels, burns in subtitles, and delivers a finished HD MP4 video ready to upload.

No subscriptions. No API fees. No cloud required. Everything runs on your own machine.

---

## ✨ Key Features

| Feature | Details |
|---|---|
| 🧠 **AI Script Writing** | Ollama (Llama3/Mistral) locally + Smart Templates fallback |
| 🗣️ **Neural Voiceover** | Microsoft Edge-TTS · 20+ voices · 50+ languages |
| 🎬 **Real Stock Footage** | Pixabay API (free) + Pexels API (free) |
| 📐 **Orientation Control** | Landscape (YouTube) · Portrait (Shorts/TikTok) · Square (Instagram) |
| 🎥 **Quality Selection** | 720p · 1080p · 1440p (2K) · 4K Ultra HD |
| 📝 **Auto Subtitles** | Burned-in captions with smart line breaks |
| 🌐 **Web UI** | Beautiful single-page app, no build step needed |
| 💬 **Multi-language** | English, Urdu, Hindi, Arabic, French, Spanish & more |
| 🎛️ **Voice Controls** | Adjustable speech rate and pitch |
| 💰 **Zero Cost** | $0/month — completely free forever |

---

## 🎯 Use Cases

- **YouTube Automation** — Generate faceless educational/documentary channels at scale
- **YouTube Shorts** — Portrait mode for viral short-form content
- **Instagram Reels / TikTok** — Square and portrait videos for social media
- **Content Agencies** — Produce client videos quickly without expensive software
- **Language Learning Channels** — Multi-language voiceover support
- **News/Facts Channels** — Template-based script generation for any topic

---

## 🏗️ How It Works

```
You type a topic
       ↓
① Script → Ollama AI (local) or Smart Templates
       ↓
② Voiceover → Microsoft Edge-TTS (free, 50+ languages)
       ↓
③ Footage → Pixabay API → topic-specific stock videos
       ↓
④ Subtitles → Auto-generated SRT, burned into video
       ↓
⑤ Assembly → FFmpeg renders final MP4
       ↓
Complete HD Video ✅ (with title, description & tags for YouTube)
```

---

## 📋 Requirements

### System
| Component | Minimum | Recommended |
|---|---|---|
| RAM | 8 GB | 16 GB+ |
| Storage | 10 GB free | 50 GB+ SSD |
| GPU | Not required | NVIDIA 4GB+ VRAM (for 4K/Ollama) |
| OS | Windows 10 | Windows 11 |
| Internet | Required for TTS + footage | Broadband |

### Tested On
- ✅ Windows 11
- ✅ 32 GB RAM
- ✅ NVIDIA RTX 6 GB VRAM
- ✅ 1 TB NVMe SSD

### Software
- Python 3.10+
- FFmpeg
- Ollama (optional — for AI scripts)

---

## 🚀 Installation

### Step 1 — Download & Extract
Download the ZIP from this repository and extract it anywhere on your PC.

### Step 2 — Install FFmpeg
Open **PowerShell as Administrator** and run:
```powershell
winget install ffmpeg
```
Or download manually from [ffmpeg.org](https://ffmpeg.org/download.html)

### Step 3 — Install Ollama (Optional — for AI scripts)
Download from [ollama.com/download](https://ollama.com/download), then run:
```bash
ollama pull llama3
```
> Without Ollama, smart keyword templates are used — videos still generate perfectly.

### Step 4 — Get Free Pixabay API Key
1. Go to [pixabay.com](https://pixabay.com) → Create free account
2. Visit [pixabay.com/api/docs](https://pixabay.com/api/docs)
3. Your API key is shown at the top of the page
4. Copy it — paste into VidForge when generating

> Free tier: 200 requests/hour, access to 4+ million HD videos

### Step 5 — Run VidForge Pro
Double-click **`START.bat`** — server starts and browser opens automatically.

---

## 🎬 How To Use

1. **Open VidForge.html** in your browser (opens automatically)
2. **Type your topic** — e.g. "Amazing Facts About Black Holes"
3. **Select Language & Voice** — English, Urdu, Hindi, Arabic + more
4. **Choose Orientation** — Landscape / Portrait / Square
5. **Choose Quality** — 720p / 1080p / 1440p / 4K
6. **Paste Pixabay API key** — for real stock footage
7. **Click Generate** — wait 3–8 minutes
8. **Download MP4** — upload directly to YouTube

---

## 🗣️ Available Voices

### English
| Voice | Description |
|---|---|
| `en-US-AriaNeural` | Female, Natural (Default) |
| `en-US-GuyNeural` | Male, Natural |
| `en-US-ChristopherNeural` | Male, Authoritative |
| `en-GB-SoniaNeural` | British Female |
| `en-GB-RyanNeural` | British Male |

### South Asian
| Voice | Description |
|---|---|
| `ur-PK-UzmaNeural` | Urdu Pakistan — Female |
| `ur-PK-AsadNeural` | Urdu Pakistan — Male |
| `hi-IN-SwaraNeural` | Hindi India — Female |
| `hi-IN-MadhurNeural` | Hindi India — Male |

### Arabic & More
| Voice | Description |
|---|---|
| `ar-SA-HamedNeural` | Arabic Saudi Arabia |
| `fr-FR-DeniseNeural` | French |
| `de-DE-ConradNeural` | German |
| `es-ES-ElviraNeural` | Spanish |

---

## 📐 Video Formats

| Orientation | Dimensions | Best For |
|---|---|---|
| 🖥️ Landscape | 16:9 | YouTube Videos |
| 📱 Portrait | 9:16 | YouTube Shorts · TikTok · Instagram Reels |
| ⬛ Square | 1:1 | Instagram Posts · Facebook |

| Quality | Resolution | File Size | Render Time |
|---|---|---|---|
| 720p | 1280×720 | ~15 MB/min | Fast |
| 1080p | 1920×1080 | ~30 MB/min | Medium |
| 1440p | 2560×1440 | ~60 MB/min | Slow |
| 4K | 3840×2160 | ~120 MB/min | Very Slow |

---

## 📡 API Reference

**Base URL:** `http://localhost:8000`

### Generate Video
```http
POST /api/generate
Content-Type: application/json

{
  "topic": "Amazing Facts About Black Holes",
  "duration": 60,
  "voice": "en-US-AriaNeural",
  "language": "English",
  "pixabay_key": "your_pixabay_key",
  "pexels_key": "optional_pexels_key",
  "quality": "1080p",
  "orientation": "landscape",
  "burn_subtitles": true,
  "tts_rate": "+0%",
  "tts_pitch": "+0Hz"
}
```

### Check Status
```http
GET /api/status/{job_id}
```

### Download Video
```http
GET /api/download/{job_id}
```

### Server Health
```http
GET /health
```

---

## 📁 Project Structure

```
VidForge-Pro/
├── server.py        ← Backend server (all AI pipeline code)
├── VidForge.html    ← Web UI (open in browser)
├── START.bat        ← One-click launcher (Windows)
├── output/          ← Generated videos saved here
└── temp/            ← Temporary files (auto-cleaned)
```

---

## 🔧 Troubleshooting

| Problem | Fix |
|---|---|
| Server offline | Run `START.bat` and keep CMD window open |
| FFmpeg not found | PowerShell Admin: `winget install ffmpeg` |
| No footage in video | Add Pixabay API key in the UI |
| TTS not working | Run: `pip install edge-tts --upgrade` |
| Video fails at 78% | Normal — subtitle fallback activates automatically |
| 4K render very slow | Normal — use 1080p for faster results |

---

## 🛠️ Tech Stack

| Component | Technology |
|---|---|
| Backend | Python 3.10+ (no frameworks) |
| AI Script | Ollama + Llama3 (local) |
| Text-to-Speech | Microsoft Edge-TTS (free) |
| Backup TTS | gTTS (Google) + pyttsx3 (offline) |
| Stock Footage | Pixabay API + Pexels API |
| Video Processing | FFmpeg + Python subprocess |
| Web UI | Vanilla HTML/CSS/JS |
| Server | Python http.server (built-in) |

---

## 📄 License

MIT License — free to use, modify, and distribute.

---

## 👨‍💻 Author

**Adeel Ghauri**
GitHub: [@adeeghauri6261](https://github.com/adeeghauri6261)

---

<p align="center">
  Made with ❤️ · 100% Free · No subscriptions · No API fees · Runs locally
</p>
